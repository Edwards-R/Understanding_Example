# BWARS Public Database
This is an export of select data from the UK's Bees Wasps and Ants Recording Society  (BWARS).

The data is intended for use in SQLite, predominantly as a training database and teaching aid. Do not use this database for scientific analysis! It is a snapshot and likely outdated. Please visit the BWARS website (https://bwars.com/index.php/content/bwars-data-download) for the most up-to-date available data.

## License
This database utilises the BWARS public resolution dataset. As such, the BWARS public data conditions apply:

>You are free to use the BWARS taxonomic and public data for any purpose provided that you acknowledge BWARS as the source of this data.

## How to use
The file `BWARS public database.sqlite3` is saved using the `sqlite3` format. Any application or extension capable of interacting with `sqlite` format files should be capable of opening this file.

The file was constructed using `DB Browser`, which can be found at https://sqlitebrowser.org/.

## Documentation
An entity-relationship diagram for the nomenclature can be found in `documentation/nomenclature erd.png`.

An entity-relationship diagram for the data can be found in `documentation/data erd.png`.